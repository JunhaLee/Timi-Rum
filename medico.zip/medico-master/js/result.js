import React, { Component } from 'react';
import Webcam from "react-webcam";
import {Img} from 'react-image'
import icon_green from './icon_green.png'
import icon_red from './icon_red.png'
const WebcamComponent = () => <Webcam />;
const key = 1;

const videoConstraints = {
  width: 1280,
  height: 720,
  facingMode: "user"
};


class App extends Component {

    render() {

        return (
            <div>
                <center>
                <h2>Development of Falling Accident Response System for the Elderly people</h2>
                <h3>Team2 : TIMI-RUM</h3>
                <br></br>
                </center>
                 <div>
                 <Webcam
                   autoPlay
                   playsInline
                   muted={true}
                   width="870"
                   height="534"/>
                    {(key==1)
                    ? <img src= {icon_red} alt="pic" />
                    :<img src= {icon_green} alt="pic" />
                    }
                 </div>
            </div>
        );
    }
}
const domContainer = document.querySelector('#result_container');
export default App;