import React, { Component } from 'react';
import Webcam from "react-webcam";
import {Img} from 'react-image'
import icon_green from './icon_green.png'
import icon_red from './icon_red.png'
const WebcamComponent = () => <Webcam />;
const key = 1;

const videoConstraints = {
  width: 1280,
  height: 720,
  facingMode: "user"
};
const e = React.createElement

class App extends Component {

    render() {

        return e(
            <div>
                 <div>
                 <Webcam
                   autoPlay
                   playsInline
                   muted={true}
                   width="870"
                   height="534"/>
                    {(key==1)
                    ? <img src= {icon_red} alt="pic" />
                    :<img src= {icon_green} alt="pic" />
                    }
                 </div>
            </div>
        );
    }
}
const domContainer = document.querySelector('#result_container');
ReactDOM.render(e(App), domContainer);
export default App;