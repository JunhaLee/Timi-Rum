import React, { Component } from 'react';
import {Img} from 'react-image'
import icon_green from './icon_green.png'
import icon_red from './icon_red.png'

const key = 1;

const e = React.createElement
class icon extends React.Component {
    constructor(props){
    super(props);
    }

    render() {

        return e(
            'Img',
              {(key==1)
              ? <img src= {icon_red} alt="pic" />
              :<img src= {icon_green} alt="pic" />
              }
        );
    }
}
const domContainer = document.querySelector('#icon_container');
ReactDOM.render(e(icon), domContainer);
