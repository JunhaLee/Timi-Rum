import React, { Component } from 'react';
import Webcam from "react-webcam";
const WebcamComponent = () => <Webcam />;

const videoConstraints = {
  width: 1280,
  height: 720,
  facingMode: "user"
};

class App extends Component {
    render() {
        return (
            <div>
                 <div>
                 <Webcam
                   autoPlay
                   playsInline
                   muted={true}
                   width="870"
                   height="534"/>
                 </div>
            </div>
        );
    }
}
export default App;